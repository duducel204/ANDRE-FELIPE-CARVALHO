export type Criticidade = 'BAIXA' | 'MEDIA' | 'ALTA' | 'CRITICA';
export type TipoEvento = 'SEGUIR' | 'DECIDIR' | 'AUTORIZACAO_EXECUCAO' | 'ALERTA' | 'ERRO' | 'HASH_REGISTRADO' | 'ALERTA_INTEGRIDADE' | 'ROLLBACK';
export type StatusPipeline = 'IDLE' | 'QUALIFICANDO' | 'ORQUESTRANDO' | 'AUDITANDO' | 'DESENHANDO' | 'VALIDANDO' | 'EXECUTANDO' | 'REGISTRANDO' | 'CONCLUIDO' | 'BLOQUEADO' | 'ERRO';

export interface LogEntry {
  seq: number;
  ts: string;
  agente: string;
  tipo: TipoEvento;
  mensagem: string;
  detalhes?: Record<string, any>;
  autorizado_por?: string;
  hash: string;
}

export interface HashRegistryEntry {
  ts: string;
  arquivo: string;
  tipo: string;
  hash_sha256: string;
  tamanho_bytes: number;
  autorizado_por: string;
}

export interface IntencaoBruta {
  texto_bruto: string;
  usuario_origem: string;
  parametros?: Record<string, any>;
}

export interface IntencaoQualificada {
  id_intencao: string;
  tipo: string;
  criticidade: Criticidade;
  parametros: Record<string, any>;
  profundidade_ciclo: number;
  duplicado_60s: boolean;
  hash?: string;
  ts: string;
}

export interface PlanoAcao {
  id_plano: string;
  id_intencao: string;
  tipo_plano: string;
  criticidade: Criticidade;
  etapas: string[];
  requer_aprovacao_humana: boolean;
  status: 'CRIADO' | 'EM_AUDITORIA' | 'APROVADO' | 'EM_EXECUCAO' | 'CONCLUIDO' | 'BLOQUEADO';
  hash?: string;
  ts: string;
}

export interface RelatorioRiscos {
  id_plano: string;
  status: 'APROVADO' | 'BLOQUEADO';
  riscos_encontrados: number;
  nivel_risco: 'BAIXO' | 'MEDIO' | 'ALTO' | 'CRITICO';
  detalhes_riscos: { id: string; descricao: string; severidade: string }[];
  hash?: string;
  ts: string;
}

export interface ArquiteturaDesign {
  id_design: string;
  componentes: Record<string, string>;
  fluxo: string;
  criterios_sucesso: number;
  hash?: string;
  ts: string;
}

export interface ValidacaoAnalista {
  conformidade: string;
  verificacoes: number;
  bloqueadores: number;
  status: 'VALIDACAO_OK' | 'REJEITADO';
  hash?: string;
  ts: string;
}

export interface AutorizacaoExecucao {
  id_autorizacao: string;
  autorizado_por: string;
  token_hash: string;
  ts: string;
}

export interface ExecucaoResultado {
  id_execucao: string;
  status: 'SUCESSO' | 'FALHA';
  etapas_concluidas: number;
  total_etapas: number;
  detalhes: Record<string, any>;
  hash?: string;
  ts: string;
}

export interface CheckpointState {
  id_checkpoint: string;
  ts: string;
  descricao: string;
  total_logs: number;
  total_hashes: number;
  agentes_estado: Record<string, string>;
  hash_integridade: string;
}

export interface AgenteInfo {
  nome: string;
  funcao: string;
  status: 'Ativo' | 'Standby' | 'Audito';
  total_execucoes: number;
  ultimo_evento?: string;
  criticidade_maxima: Criticidade;
}
