import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { PipelineRunnerView } from './components/PipelineRunnerView';
import { AuditLogView } from './components/AuditLogView';
import { ArtifactInspectorView } from './components/ArtifactInspectorView';
import { ContractsView } from './components/ContractsView';
import { RollbackView } from './components/RollbackView';
import { AgentMatrixView } from './components/AgentMatrixView';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [summary, setSummary] = useState<any>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [hashes, setHashes] = useState<any[]>([]);
  const [artifacts, setArtifacts] = useState<any[]>([]);
  const [agentes, setAgentes] = useState<any[]>([]);
  const [checkpoints, setCheckpoints] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAllData = async () => {
    try {
      const [sumRes, logsRes, hashesRes, artRes, agRes, cpRes] = await Promise.all([
        fetch('/api/logs/summary').then(r => r.json()),
        fetch('/api/logs?limite=150').then(r => r.json()),
        fetch('/api/hashes?limite=50').then(r => r.json()),
        fetch('/api/artifacts').then(r => r.json()),
        fetch('/api/agentes').then(r => r.json()),
        fetch('/api/checkpoints').then(r => r.json()),
      ]);

      setSummary(sumRes);
      setLogs(logsRes);
      setHashes(hashesRes);
      setArtifacts(artRes);
      setAgentes(agRes);
      setCheckpoints(cpRes);
    } catch (err) {
      console.error('Erro ao buscar dados do DTGE Engine:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
    const interval = setInterval(fetchAllData, 10000); // refresh every 10s
    return () => clearInterval(interval);
  }, []);

  const handleRunPipeline = async (input: { texto_bruto: string; usuario_origem: string }) => {
    const res = await fetch('/api/pipeline/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    return res.json();
  };

  const handleVerifyHash = async (conteudo: string, hash_esperado: string) => {
    const res = await fetch('/api/hashes/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ conteudo, hash_esperado }),
    });
    const data = await res.json();
    return data.integro;
  };

  const handleCreateCheckpoint = async (descricao: string) => {
    const res = await fetch('/api/checkpoints', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ descricao }),
    });
    return res.json();
  };

  const handleTriggerRollback = async (id_checkpoint: string) => {
    const res = await fetch('/api/rollback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id_checkpoint }),
    });
    return res.json();
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col font-sans">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        summary={summary}
        onRefresh={fetchAllData}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-4">
            <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs font-mono text-slate-400">Carregando Dream Team Governance Engine...</p>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <DashboardView
                summary={summary}
                logs={logs}
                agentes={agentes}
                onNavigate={setActiveTab}
              />
            )}

            {activeTab === 'pipeline' && (
              <PipelineRunnerView
                onRunPipeline={handleRunPipeline}
                onRefreshAll={fetchAllData}
              />
            )}

            {activeTab === 'auditoria' && (
              <AuditLogView
                logs={logs}
                summary={summary}
                onVerifyHash={handleVerifyHash}
              />
            )}

            {activeTab === 'artefatos' && (
              <ArtifactInspectorView
                artifacts={artifacts}
                hashesRegistry={hashes}
              />
            )}

            {activeTab === 'agentes' && (
              <AgentMatrixView
                agentes={agentes}
                onNavigate={setActiveTab}
              />
            )}

            {activeTab === 'contratos' && <ContractsView />}

            {activeTab === 'rollback' && (
              <RollbackView
                checkpoints={checkpoints}
                onCreateCheckpoint={handleCreateCheckpoint}
                onTriggerRollback={handleTriggerRollback}
                onRefreshAll={fetchAllData}
              />
            )}
          </>
        )}
      </main>

      <footer className="border-t border-slate-800/60 py-4 bg-[#060a12] text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            <span className="font-bold text-slate-400">DTGE</span> — Dream Team Governance Engine | Auditoria Multiagente Imutável
          </div>
          <div className="font-mono text-[11px] text-slate-600">
            SHA-256 Ledger • Protocolo Claude DTGE v1.0
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
