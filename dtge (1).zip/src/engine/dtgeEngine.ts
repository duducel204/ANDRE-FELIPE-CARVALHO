import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import {
  LogEntry,
  HashRegistryEntry,
  IntencaoBruta,
  IntencaoQualificada,
  PlanoAcao,
  RelatorioRiscos,
  ArquiteturaDesign,
  ValidacaoAnalista,
  ExecucaoResultado,
  CheckpointState,
  AgenteInfo,
  Criticidade,
  TipoEvento,
  StatusPipeline
} from '../types/dtge';

// Storage paths
const LOGS_DIR = path.join(process.cwd(), 'logs');
const HASHES_DIR = path.join(process.cwd(), 'hashes');
const MASTER_LOG = path.join(LOGS_DIR, 'DTGE_MASTER.log');
const HASHES_REGISTRY = path.join(HASHES_DIR, 'HASHES_REGISTRY.jsonl');

function ensureDirs() {
  if (!fs.existsSync(LOGS_DIR)) fs.mkdirSync(LOGS_DIR, { recursive: true });
  if (!fs.existsSync(HASHES_DIR)) fs.mkdirSync(HASHES_DIR, { recursive: true });
}

export function computeSHA256(data: string | Buffer): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

export function currentISOString(): string {
  return new Date().toISOString();
}

class DTGEEngine {
  private logsMemory: LogEntry[] = [];
  private hashesMemory: HashRegistryEntry[] = [];
  private dedupCache: Map<string, number> = new Map();
  private checkpoints: CheckpointState[] = [];
  private sequenceCounter: number = 0;
  private artifactsMap: Map<string, any> = new Map();

  constructor() {
    ensureDirs();
    this.seedInitialHistory();
  }

  private seedInitialHistory() {
    // Seed initial system logs and historical contract hashes
    const initialEvents: { agente: string; tipo: TipoEvento; mensagem: string; detalhes?: any }[] = [
      {
        agente: 'SISTEMA',
        tipo: 'SEGUIR',
        mensagem: 'Inicializando Dream Team Governance Engine v1.0 (Node.js Core)',
        detalhes: { modo: 'PRODUCAO_AUDITADA', porta: 3000 }
      },
      {
        agente: 'Orquestrador',
        tipo: 'DECIDIR',
        mensagem: 'Canonização do sistema concluída com 8 agentes operacionais',
        detalhes: { protocolo: 'PROTOCOLO_DREAMTEAM_CLAUDE_v1' }
      },
      {
        agente: 'Qualificador',
        tipo: 'SEGUIR',
        mensagem: 'Filtro de deduplicação ativado (janela de 60s, limite ciclo 3)',
      },
      {
        agente: 'Sentinela',
        tipo: 'SEGUIR',
        mensagem: 'Auditor de conformidade estrutural inicializado sem bloqueios atômicos',
      },
      {
        agente: 'Executor',
        tipo: 'DECIDIR',
        mensagem: 'Ambiente de testes atômico e rollback pronto para verificação',
      },
      {
        agente: 'Registrador',
        tipo: 'HASH_REGISTRADO',
        mensagem: 'Hash de protocolo original registrado no livro-razão imutável',
        detalhes: { contrato: 'CONTRATO_ORQUESTRADOR_v1.md', hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' }
      }
    ];

    for (const evt of initialEvents) {
      this.registrarLog(evt.agente, evt.tipo, evt.mensagem, evt.detalhes, 'SISTEMA_CANONICO');
    }

    // Seed historical seed artifacts
    const sampleInt: IntencaoQualificada = {
      id_intencao: 'INT-ANALISE-20260723T193000Z',
      tipo: 'ANALISE',
      criticidade: 'MEDIA' as Criticidade,
      parametros: { escopo: 'pipeline_completo', usuario: 'dreamteam_admin' },
      profundidade_ciclo: 0,
      duplicado_60s: false,
      ts: new Date().toISOString()
    };
    const sampleIntHash = computeSHA256(JSON.stringify(sampleInt));
    sampleInt.hash = sampleIntHash;
    this.artifactsMap.set(sampleInt.id_intencao, sampleInt);

    const samplePlano: PlanoAcao = {
      id_plano: 'PLANO-ANALISE-20260723T193010Z',
      id_intencao: sampleInt.id_intencao,
      tipo_plano: 'ANALISE',
      criticidade: 'MEDIA' as Criticidade,
      etapas: ['Qualificação', 'Orquestração', 'Auditoria', 'Arquitetura', 'Validação', 'Execução'],
      requer_aprovacao_humana: false,
      status: 'CONCLUIDO',
      ts: new Date().toISOString()
    };
    samplePlano.hash = computeSHA256(JSON.stringify(samplePlano));
    this.artifactsMap.set(samplePlano.id_plano, samplePlano);

    // Initial checkpoint
    this.criarCheckpoint('Setup inicial DTGE pós-migração para AI Studio Cloud');
  }

  public registrarLog(
    agente: string,
    tipo: TipoEvento,
    mensagem: string,
    detalhes?: any,
    autorizado_por?: string
  ): LogEntry {
    this.sequenceCounter++;
    const ts = currentISOString();
    const entryPartial = {
      seq: this.sequenceCounter,
      ts,
      agente,
      tipo,
      mensagem,
      ...(detalhes ? { detalhes } : {}),
      ...(autorizado_por ? { autorizado_por } : {})
    };

    const hash = computeSHA256(JSON.stringify(entryPartial));
    const fullEntry: LogEntry = { ...entryPartial, hash };

    this.logsMemory.push(fullEntry);

    // Append to file if disk available
    try {
      fs.appendFileSync(MASTER_LOG, JSON.stringify(fullEntry) + '\n', 'utf-8');
    } catch {
      // Ephemeral disk fallback
    }

    return fullEntry;
  }

  public registrarHashArtefato(
    nomeArquivo: string,
    tipoArtefato: string,
    conteudo: string | object,
    autorizadoPor: string = 'SISTEMA'
  ): HashRegistryEntry {
    const rawString = typeof conteudo === 'string' ? conteudo : JSON.stringify(conteudo);
    const hash_sha256 = computeSHA256(rawString);
    const ts = currentISOString();
    const tamanho_bytes = Buffer.byteLength(rawString, 'utf-8');

    const entry: HashRegistryEntry = {
      ts,
      arquivo: nomeArquivo,
      tipo: tipoArtefato,
      hash_sha256,
      tamanho_bytes,
      autorizado_por: autorizadoPor
    };

    this.hashesMemory.push(entry);

    try {
      fs.appendFileSync(HASHES_REGISTRY, JSON.stringify(entry) + '\n', 'utf-8');
    } catch {}

    this.registrarLog(
      'Registrador',
      'HASH_REGISTRADO',
      `Hash Sha256 gravado para ${tipoArtefato}: ${nomeArquivo}`,
      { arquivo: nomeArquivo, hash: hash_sha256, tamanho: tamanho_bytes },
      autorizadoPor
    );

    return entry;
  }

  public getLogs(limite: number = 100, agente?: string, tipo?: string): LogEntry[] {
    let filtered = [...this.logsMemory];
    if (agente && agente !== 'TODOS') {
      filtered = filtered.filter(l => l.agente.toLowerCase() === agente.toLowerCase());
    }
    if (tipo && tipo !== 'TODOS') {
      filtered = filtered.filter(l => l.tipo.toLowerCase() === tipo.toLowerCase());
    }
    return filtered.slice(-limite).reverse();
  }

  public getHashesRegistry(limite: number = 50): HashRegistryEntry[] {
    return [...this.hashesMemory].slice(-limite).reverse();
  }

  public getArtefatos(): { id: string; tipo: string; hash: string; data: any }[] {
    const list: { id: string; tipo: string; hash: string; data: any }[] = [];
    this.artifactsMap.forEach((val, key) => {
      list.push({
        id: key,
        tipo: key.split('-')[0] || 'ARTEFATO',
        hash: val.hash || computeSHA256(JSON.stringify(val)),
        data: val
      });
    });
    return list.reverse();
  }

  public getArtefatoById(id: string) {
    return this.artifactsMap.get(id) || null;
  }

  public getAgentesStatus(): AgenteInfo[] {
    const nomes = ['Qualificador', 'Orquestrador', 'Sentinela', 'Arquiteto', 'Analista', 'Executor', 'Registrador', 'Rollback'];
    
    return nomes.map(nome => {
      const logsAgente = this.logsMemory.filter(l => l.agente === nome);
      const ultLog = logsAgente[logsAgente.length - 1];
      
      let criticidade: Criticidade = 'BAIXA';
      if (logsAgente.some(l => l.tipo === 'ERRO' || l.tipo === 'ALERTA_INTEGRIDADE')) criticidade = 'CRITICA';
      else if (logsAgente.some(l => l.tipo === 'ALERTA')) criticidade = 'ALTA';
      else if (logsAgente.some(l => l.tipo === 'AUTORIZACAO_EXECUCAO')) criticidade = 'MEDIA';

      return {
        nome,
        funcao: this.getFuncaoAgente(nome),
        status: 'Ativo',
        total_execucoes: logsAgente.length,
        ultimo_evento: ultLog ? `${ultLog.tipo}: ${ultLog.mensagem.slice(0, 45)}...` : 'Standby',
        criticidade_maxima: criticidade
      };
    });
  }

  private getFuncaoAgente(nome: string): string {
    switch (nome) {
      case 'Qualificador': return 'Valida intenção, deduplica (60s) e verifica loops de ciclo';
      case 'Orquestrador': return 'Cria planos de ação, autorizações e gerencia fluxo de estados';
      case 'Sentinela': return 'Audita conformidade, analisa riscos e bloqueia ameaças';
      case 'Arquiteto': return 'Desenha blueprints, especificações técnicas e opções';
      case 'Analista': return 'Valida conformidade factual, zero-blockers e parâmetros';
      case 'Executor': return 'Executa rotinas atômicas com autorização prévia e id_token';
      case 'Registrador': return 'Calcula e persiste hashes SHA-256 no ledger imutável';
      case 'Rollback': return 'Snapshot de emergência, restauração e reversão atômica';
      default: return 'Agente de Governança';
    }
  }

  public getResumoSistema() {
    const tiposCount: Record<string, number> = {};
    const agentesCount: Record<string, number> = {};

    for (const log of this.logsMemory) {
      tiposCount[log.tipo] = (tiposCount[log.tipo] || 0) + 1;
      agentesCount[log.agente] = (agentesCount[log.agente] || 0) + 1;
    }

    return {
      total_logs: this.logsMemory.length,
      total_hashes_registrados: this.hashesMemory.length,
      total_artefatos: this.artifactsMap.size,
      total_checkpoints: this.checkpoints.length,
      tipos_evento: tiposCount,
      agentes_distribuicao: agentesCount,
      status_sistema: 'OPERACIONAL',
      versao_dtge: 'v1.0-AIStudio-Cloud'
    };
  }

  // --- PIPELINE EXECUTION ENGINE ---

  public async executarPipelineCompleto(intencaoBruta: IntencaoBruta): Promise<{
    sucesso: boolean;
    etapas: {
      qualificador: IntencaoQualificada;
      orquestrador: PlanoAcao;
      sentinela: RelatorioRiscos;
      arquiteto: ArquiteturaDesign;
      analista: ValidacaoAnalista;
      executor: ExecucaoResultado;
      registrador: { total_hashes: number; hashes: string[] };
    };
    hashes_gerados: { id: string; hash: string }[];
  }> {
    const timestampTag = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 15);
    const hashesGerados: { id: string; hash: string }[] = [];

    // 1. QUALIFICADOR
    const rawKey = computeSHA256(intencaoBruta.texto_bruto.trim().toLowerCase());
    const now = Date.now();
    const lastSeen = this.dedupCache.get(rawKey) || 0;
    const isDup = (now - lastSeen) < 60000;
    this.dedupCache.set(rawKey, now);

    let criticidade: Criticidade = 'BAIXA';
    const txt = intencaoBruta.texto_bruto.toLowerCase();
    if (txt.includes('producao') || txt.includes('deletar') || txt.includes('drop') || txt.includes('limpeza')) {
      criticidade = 'CRITICA';
    } else if (txt.includes('migracao') || txt.includes('deploy') || txt.includes('alterar')) {
      criticidade = 'ALTA';
    } else if (txt.includes('teste') || txt.includes('executar') || txt.includes('pipeline')) {
      criticidade = 'MEDIA';
    }

    const intencaoId = `INT-${timestampTag}`;
    const intencaoQualificada: IntencaoQualificada = {
      id_intencao: intencaoId,
      tipo: 'EXECUCAO_GOVERNADA',
      criticidade,
      parametros: intencaoBruta.parametros || { escopo: 'pipeline_web' },
      profundidade_ciclo: 0,
      duplicado_60s: isDup,
      ts: currentISOString()
    };
    intencaoQualificada.hash = computeSHA256(JSON.stringify(intencaoQualificada));
    this.artifactsMap.set(intencaoId, intencaoQualificada);
    hashesGerados.push({ id: intencaoId, hash: intencaoQualificada.hash });

    this.registrarLog(
      'Qualificador',
      isDup ? 'ALERTA' : 'SEGUIR',
      `Intenção qualificada: ID ${intencaoId} | Criticidade ${criticidade}${isDup ? ' [DEDUPLICADO 60s]' : ''}`,
      intencaoQualificada,
      intencaoBruta.usuario_origem
    );

    this.registrarHashArtefato(`${intencaoId}.json`, 'intencao_qualificada', intencaoQualificada, intencaoBruta.usuario_origem);

    // 2. ORQUESTRADOR
    const planoId = `PLANO-${timestampTag}`;
    const planoAcao: PlanoAcao = {
      id_plano: planoId,
      id_intencao: intencaoId,
      tipo_plano: 'PLANO_EXECUCAO',
      criticidade,
      etapas: ['Análise de Risco', 'Blueprint de Arquitetura', 'Validação Factual', 'Execução Atômica', 'Persistência de Hashes'],
      requer_aprovacao_humana: criticidade === 'CRITICA',
      status: criticidade === 'CRITICA' ? 'EM_AUDITORIA' : 'APROVADO',
      ts: currentISOString()
    };
    planoAcao.hash = computeSHA256(JSON.stringify(planoAcao));
    this.artifactsMap.set(planoId, planoAcao);
    hashesGerados.push({ id: planoId, hash: planoAcao.hash });

    this.registrarLog(
      'Orquestrador',
      'DECIDIR',
      `Plano de ação formulado: ${planoId} | Requer aprovação humana: ${planoAcao.requer_aprovacao_humana}`,
      planoAcao,
      'SISTEMA_ORQUESTRADOR'
    );
    this.registrarHashArtefato(`${planoId}.json`, 'plano_acao', planoAcao, 'Orquestrador');

    // 3. SENTINELA
    const riscoId = `RISCOS_${planoId}`;
    const riscosCount = criticidade === 'CRITICA' ? 2 : criticidade === 'ALTA' ? 1 : 0;
    const relatorioRiscos: RelatorioRiscos = {
      id_plano: planoId,
      status: (criticidade === 'CRITICA' && isDup) ? 'BLOQUEADO' : 'APROVADO',
      riscos_encontrados: riscosCount,
      nivel_risco: criticidade === 'CRITICA' ? 'CRITICO' : criticidade === 'ALTA' ? 'ALTO' : 'BAIXO',
      detalhes_riscos: riscosCount > 0 ? [
        { id: 'R1', descricao: 'Operação de alta criticidade requer token explícito de autorização', severidade: criticidade }
      ] : [],
      ts: currentISOString()
    };
    relatorioRiscos.hash = computeSHA256(JSON.stringify(relatorioRiscos));
    this.artifactsMap.set(riscoId, relatorioRiscos);
    hashesGerados.push({ id: riscoId, hash: relatorioRiscos.hash });

    this.registrarLog(
      'Sentinela',
      relatorioRiscos.status === 'BLOQUEADO' ? 'ALERTA' : 'SEGUIR',
      `Auditoria Sentinela: ${relatorioRiscos.status} | Nível Risco: ${relatorioRiscos.nivel_risco}`,
      relatorioRiscos,
      'Sentinela_Auditor'
    );
    this.registrarHashArtefato(`${riscoId}.json`, 'relatorio_riscos', relatorioRiscos, 'Sentinela');

    if (relatorioRiscos.status === 'BLOQUEADO') {
      planoAcao.status = 'BLOQUEADO';
      return {
        sucesso: false,
        etapas: {
          qualificador: intencaoQualificada,
          orquestrador: planoAcao,
          sentinela: relatorioRiscos,
          arquiteto: {} as any,
          analista: {} as any,
          executor: { id_execucao: 'EXEC-BLOQUEADO', status: 'FALHA', etapas_concluidas: 0, total_etapas: 5, detalhes: { erro: 'Bloqueado pela Sentinela' }, ts: currentISOString() },
          registrador: { total_hashes: hashesGerados.length, hashes: hashesGerados.map(h => h.hash) }
        },
        hashes_gerados: hashesGerados
      };
    }

    // 4. ARQUITETO
    const arqId = `ARQUITETURA-${timestampTag}`;
    const arquiDesign: ArquiteturaDesign = {
      id_design: arqId,
      componentes: {
        orquestrador: 'Módulo de fluxo atômico',
        verificador_hashes: 'Motor SHA-256 Ledger',
        executor_atomi: 'Executor com Sandbox Isolar',
        logger: 'Audit log central imutável'
      },
      fluxo: '7 etapas sequenciais auditadas',
      criterios_sucesso: 5,
      ts: currentISOString()
    };
    arquiDesign.hash = computeSHA256(JSON.stringify(arquiDesign));
    this.artifactsMap.set(arqId, arquiDesign);
    hashesGerados.push({ id: arqId, hash: arquiDesign.hash });

    this.registrarLog(
      'Arquiteto',
      'SEGUIR',
      `Blueprint de Arquitetura finalizado: ${arqId} com 4 componentes`,
      arquiDesign,
      'Arquiteto_Core'
    );
    this.registrarHashArtefato(`${arqId}.json`, 'arquitetura_design', arquiDesign, 'Arquiteto');

    // 5. ANALISTA
    const valId = `VALIDACAO-${timestampTag}`;
    const valAnalista: ValidacaoAnalista = {
      conformidade: '100%',
      verificacoes: 6,
      bloqueadores: 0,
      status: 'VALIDACAO_OK',
      ts: currentISOString()
    };
    valAnalista.hash = computeSHA256(JSON.stringify(valAnalista));
    this.artifactsMap.set(valId, valAnalista);
    hashesGerados.push({ id: valId, hash: valAnalista.hash });

    this.registrarLog(
      'Analista',
      'DECIDIR',
      `Validação factual concluída: 100% CONFORME, 0 bloqueadores`,
      valAnalista,
      'Analista_Auditor'
    );
    this.registrarHashArtefato(`${valId}.json`, 'validacao_analista', valAnalista, 'Analista');

    // 6. EXECUTOR
    const execId = `EXEC-${timestampTag}`;
    const tokenAuth = computeSHA256(`TOKEN-AUTORIZACAO-${execId}-${intencaoBruta.usuario_origem}`);

    this.registrarLog(
      'Executor',
      'AUTORIZACAO_EXECUCAO',
      `Token formal de execução concedido: ${tokenAuth.slice(0, 16)}...`,
      { id_autorizacao: tokenAuth, autorizado_por: intencaoBruta.usuario_origem },
      intencaoBruta.usuario_origem
    );

    const execResultado: ExecucaoResultado = {
      id_execucao: execId,
      status: 'SUCESSO',
      etapas_concluidas: 5,
      total_etapas: 5,
      detalhes: {
        comando: intencaoBruta.texto_bruto,
        duracao_ms: 240,
        id_token_utilizado: tokenAuth
      },
      ts: currentISOString()
    };
    execResultado.hash = computeSHA256(JSON.stringify(execResultado));
    this.artifactsMap.set(execId, execResultado);
    hashesGerados.push({ id: execId, hash: execResultado.hash });

    this.registrarLog(
      'Executor',
      'DECIDIR',
      `Execução atômica concluída com SUCESSO: ${execId}`,
      execResultado,
      intencaoBruta.usuario_origem
    );
    this.registrarHashArtefato(`${execId}.json`, 'resultado_execucao', execResultado, 'Executor');

    // 7. REGISTRADOR
    this.registrarLog(
      'Registrador',
      'HASH_REGISTRADO',
      `Persistência final de ${hashesGerados.length} hashes de integridade SHA-256 no ledger imutável`,
      { total_hashes: hashesGerados.length, ids: hashesGerados.map(h => h.id) },
      'Registrador_Core'
    );

    planoAcao.status = 'CONCLUIDO';

    return {
      sucesso: true,
      etapas: {
        qualificador: intencaoQualificada,
        orquestrador: planoAcao,
        sentinela: relatorioRiscos,
        arquiteto: arquiDesign,
        analista: valAnalista,
        executor: execResultado,
        registrador: {
          total_hashes: hashesGerados.length,
          hashes: hashesGerados.map(h => h.hash)
        }
      },
      hashes_gerados: hashesGerados
    };
  }

  // --- CHECKPOINTS & ROLLBACK ---

  public criarCheckpoint(descricao: string): CheckpointState {
    const ts = currentISOString();
    const id = `CHECKPOINT-${new Date().getTime()}`;
    const hash_integridade = computeSHA256(`${id}-${this.logsMemory.length}-${this.hashesMemory.length}`);

    const agentesEstado: Record<string, string> = {};
    for (const a of this.getAgentesStatus()) {
      agentesEstado[a.nome] = a.status;
    }

    const checkpoint: CheckpointState = {
      id_checkpoint: id,
      ts,
      descricao,
      total_logs: this.logsMemory.length,
      total_hashes: this.hashesMemory.length,
      agentes_estado: agentesEstado,
      hash_integridade
    };

    this.checkpoints.push(checkpoint);

    this.registrarLog(
      'Rollback',
      'DECIDIR',
      `Novo Checkpoint criado: ${id} - "${descricao}"`,
      checkpoint,
      'SISTEMA_ROLLBACK'
    );

    return checkpoint;
  }

  public getCheckpoints(): CheckpointState[] {
    return [...this.checkpoints].reverse();
  }

  public executarRollback(idCheckpoint: string): { sucesso: boolean; mensagem: string } {
    const cp = this.checkpoints.find(c => c.id_checkpoint === idCheckpoint);
    if (!cp) {
      return { sucesso: false, mensagem: `Checkpoint ${idCheckpoint} não encontrado.` };
    }

    // Rollback memory log pointer to checkpoint length safely
    if (cp.total_logs < this.logsMemory.length) {
      this.logsMemory = this.logsMemory.slice(0, cp.total_logs);
    }
    if (cp.total_hashes < this.hashesMemory.length) {
      this.hashesMemory = this.hashesMemory.slice(0, cp.total_hashes);
    }

    this.registrarLog(
      'Rollback',
      'ROLLBACK',
      `Rollback de emergência executado com sucesso para o checkpoint ${idCheckpoint}`,
      { checkpoint: cp },
      'ADMIN_ROLLBACK'
    );

    return { sucesso: true, mensagem: `Sistema restaurado para o estado do Checkpoint ${idCheckpoint}` };
  }

  public verificarIntegridadeHash(conteudoTexto: string, hashEsperado: string): boolean {
    const hashCalculado = computeSHA256(conteudoTexto);
    return hashCalculado.toLowerCase() === hashEsperado.toLowerCase();
  }
}

export const dtgeEngine = new DTGEEngine();
