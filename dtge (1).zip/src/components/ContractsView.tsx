import React, { useState, useEffect } from 'react';
import { ScrollText, Search, BookOpen, ShieldCheck, Copy, Check, FileText } from 'lucide-react';

interface ContractDoc {
  filename: string;
  title: string;
  content: string;
}

export const ContractsView: React.FC = () => {
  const [contracts, setContracts] = useState<ContractDoc[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>('PROTOCOLO_DREAMTEAM_CLAUDE_v1.md');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/contracts')
      .then(r => r.json())
      .then(data => {
        setContracts(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const activeDoc = contracts.find(c => c.filename === selectedFile) || contracts[0];

  const handleCopy = () => {
    if (!activeDoc) return;
    navigator.clipboard.writeText(activeDoc.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredContracts = contracts.filter(c => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return c.title.toLowerCase().includes(term) || c.filename.toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-blue-400" />
            <h2 className="text-xl font-bold text-white">Contratos e Especificações de Canonização</h2>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Regras formais, definições de agentes, delimitações de estado (SEGUIR / DECIDIR / AUTORIZACAO) e salvaguardas canonizadas.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-[#080d1a] px-3.5 py-2 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{contracts.length} Documentos Canonizados</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar file browser */}
        <div className="lg:col-span-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Buscar contratos..."
              className="w-full bg-[#080d1a] border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-slate-200 outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-1.5 max-h-[550px] overflow-y-auto pr-1">
            {loading ? (
              <div className="text-xs text-slate-500 p-4">Carregando documentos...</div>
            ) : (
              filteredContracts.map(c => {
                const isSelected = selectedFile === c.filename;
                const isProtocol = c.filename.includes('PROTOCOLO') || c.filename.includes('BRIEFING');
                const isCanon = c.filename.includes('CANONIZACAO');

                return (
                  <button
                    key={c.filename}
                    onClick={() => setSelectedFile(c.filename)}
                    className={`w-full text-left p-3 rounded-xl border transition-all text-xs flex items-center justify-between ${
                      isSelected
                        ? 'bg-blue-600/20 border-blue-500 text-white font-semibold shadow-md'
                        : 'bg-[#0e1526] border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2 truncate">
                      <FileText className={`w-4 h-4 shrink-0 ${isProtocol ? 'text-amber-400' : isCanon ? 'text-purple-400' : 'text-blue-400'}`} />
                      <span className="truncate">{c.title}</span>
                    </div>

                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded uppercase ${
                        isProtocol
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          : isCanon
                          ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                          : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                      }`}
                    >
                      {isProtocol ? 'Prot' : isCanon ? 'Canon' : 'Contrato'}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Contract Text Reader */}
        <div className="lg:col-span-8">
          {activeDoc ? (
            <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <ScrollText className="w-5 h-5 text-blue-400" />
                  <h3 className="font-bold text-sm text-white font-mono">{activeDoc.filename}</h3>
                </div>

                <button
                  onClick={handleCopy}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center space-x-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copiado!' : 'Copiar Texto'}</span>
                </button>
              </div>

              <div className="bg-[#080d1a] p-5 rounded-xl border border-slate-800 max-h-[500px] overflow-y-auto">
                <pre className="text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed">
                  {activeDoc.content}
                </pre>
              </div>
            </div>
          ) : (
            <div className="bg-[#0e1526] p-8 rounded-2xl border border-slate-800 text-center text-slate-500 text-xs">
              Selecione um contrato para visualizar.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
