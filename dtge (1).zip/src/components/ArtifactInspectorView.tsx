import React, { useState } from 'react';
import { Database, FileCode, Hash, Download, Copy, Check, ShieldCheck, Search } from 'lucide-react';

interface ArtifactInspectorViewProps {
  artifacts: any[];
  hashesRegistry: any[];
}

export const ArtifactInspectorView: React.FC<ArtifactInspectorViewProps> = ({ artifacts, hashesRegistry }) => {
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(
    artifacts.length > 0 ? artifacts[0].id : null
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const selectedArtifact = artifacts.find(a => a.id === selectedArtifactId) || artifacts[0];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(text);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const handleDownload = (art: any) => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(art.data, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${art.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const filteredArtifacts = artifacts.filter(art => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return art.id.toLowerCase().includes(term) || art.tipo.toLowerCase().includes(term) || art.hash.toLowerCase().includes(term);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-blue-400" />
            <h2 className="text-xl font-bold text-white">Inspetor de Artefatos & Hashes</h2>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Repositório de artefatos gerados pelo fluxo multiagente com validação de assinatura e integridade.
          </p>
        </div>

        <div className="flex items-center space-x-3 bg-[#080d1a] px-3.5 py-2 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>HASHES_REGISTRY.jsonl</span>
          <span className="text-slate-500">|</span>
          <span className="text-emerald-400 font-bold">{artifacts.length} Artefatos</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Artifacts List Sidebar */}
        <div className="lg:col-span-5 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Filtrar por ID do artefato ou hash..."
              className="w-full bg-[#080d1a] border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-slate-200 outline-none focus:border-blue-500"
            />
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredArtifacts.map(art => {
              const isSelected = selectedArtifact?.id === art.id;
              return (
                <div
                  key={art.id}
                  onClick={() => setSelectedArtifactId(art.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500 text-white shadow-md'
                      : 'bg-[#0e1526] border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-blue-500/10 text-blue-400 rounded border border-blue-500/20">
                      {art.tipo}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">{art.data?.ts ? new Date(art.data.ts).toLocaleTimeString('pt-BR') : 'Agora'}</span>
                  </div>
                  <div className="font-bold text-xs font-mono text-slate-100 mt-1.5 truncate">{art.id}</div>
                  <div className="text-[10px] font-mono text-slate-400 truncate mt-1">
                    SHA-256: {art.hash.slice(0, 16)}...
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Artifact Viewer */}
        <div className="lg:col-span-7">
          {selectedArtifact ? (
            <div className="bg-[#0e1526] p-5 rounded-2xl border border-slate-800 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <FileCode className="w-4 h-4 text-blue-400" />
                    <span className="font-bold text-sm text-white font-mono">{selectedArtifact.id}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">Tipo: {selectedArtifact.tipo}</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleCopy(selectedArtifact.hash)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 flex items-center space-x-1"
                  >
                    {copiedHash === selectedArtifact.hash ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>Copiar Hash</span>
                  </button>

                  <button
                    onClick={() => handleDownload(selectedArtifact)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg shadow-md flex items-center space-x-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download JSON</span>
                  </button>
                </div>
              </div>

              {/* Hash Banner */}
              <div className="p-3 bg-[#080d1a] rounded-xl border border-slate-800 text-xs font-mono flex items-center space-x-2">
                <Hash className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-slate-400">Assinatura SHA-256:</span>
                <span className="text-emerald-300 font-bold truncate">{selectedArtifact.hash}</span>
              </div>

              {/* Payload Viewer */}
              <div className="bg-[#080d1a] p-4 rounded-xl border border-slate-800 overflow-x-auto max-h-[400px]">
                <pre className="text-xs font-mono text-blue-200 leading-relaxed">
                  {JSON.stringify(selectedArtifact.data, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <div className="bg-[#0e1526] p-8 rounded-2xl border border-slate-800 text-center text-slate-500 text-xs">
              Selecione um artefato para inspecionar.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
