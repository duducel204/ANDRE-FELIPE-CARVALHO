import React from 'react';
import { Shield, Activity, FileCheck, Hash, Terminal, Cpu, ArrowRight, CheckCircle2, AlertTriangle, Key } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

interface DashboardViewProps {
  summary: any;
  logs: any[];
  agentes: any[];
  onNavigate: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ summary, logs, agentes, onNavigate }) => {
  const tiposData = Object.entries(summary?.tipos_evento || {}).map(([name, count]) => ({
    name,
    count: count as number,
  }));

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];

  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/60 rounded-2xl p-6 border border-blue-500/20 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 text-xs font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30 rounded-md">
                Governança Multiagente Ativa
              </span>
              <span className="text-slate-400 text-xs font-mono">Modo: Imutável SHA-256</span>
            </div>
            <h1 className="text-2xl font-bold text-white mt-2">Dream Team Governance Engine (DTGE)</h1>
            <p className="text-slate-300 text-sm max-w-2xl mt-1">
              Painel central de auditoria, controle de integridade de artefatos, rastreabilidade ponta a ponta e execução atômica governada por 8 agentes independentes.
            </p>
          </div>
          <button
            onClick={() => onNavigate('pipeline')}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg shadow-blue-600/30 flex items-center space-x-2 whitespace-nowrap"
          >
            <Cpu className="w-4 h-4" />
            <span>Executar Nova Intenção</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0e1526] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 text-xs font-medium">Registros de Auditoria</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Terminal className="w-4 h-4 text-blue-400" />
            </div>
          </div>
          <div className="text-2xl font-extrabold font-mono text-white mt-2">{summary?.total_logs || 0}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center space-x-1">
            <span className="text-emerald-400 font-medium">Trilha master</span>
            <span>em DTGE_MASTER.log</span>
          </div>
        </div>

        <div className="bg-[#0e1526] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 text-xs font-medium">Hashes SHA-256 no Ledger</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
              <Hash className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div className="text-2xl font-extrabold font-mono text-white mt-2">{summary?.total_hashes_registrados || 0}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center space-x-1">
            <span className="text-emerald-400 font-medium">100% Verificáveis</span>
            <span>sem adulteração</span>
          </div>
        </div>

        <div className="bg-[#0e1526] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 text-xs font-medium">Agentes Governança</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center">
              <Shield className="w-4 h-4 text-indigo-400" />
            </div>
          </div>
          <div className="text-2xl font-extrabold font-mono text-white mt-2">{agentes.length || 8} / 8</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center space-x-1">
            <span className="text-indigo-400 font-medium">Contratos Ativos</span>
            <span>fases SEGUIR e DECIDIR</span>
          </div>
        </div>

        <div className="bg-[#0e1526] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 text-xs font-medium">Status do Sistema</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
              <Activity className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-emerald-400 mt-2">OPERACIONAL</div>
          <div className="text-[11px] text-slate-400 mt-1">
            Zero bloqueios pendentes
          </div>
        </div>
      </div>

      {/* Analytics & Distribution Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Events Chart */}
        <div className="lg:col-span-2 bg-[#0e1526] p-5 rounded-xl border border-slate-800 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Eventos por Tipo de Governança</h3>
              <p className="text-xs text-slate-400">Classificação atômica de ações e decisões</p>
            </div>
            <button
              onClick={() => onNavigate('auditoria')}
              className="text-xs text-blue-400 hover:underline flex items-center space-x-1"
            >
              <span>Ver todos os logs</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tiposData}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#f8fafc' }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {tiposData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* System Safeguards Checklist */}
        <div className="bg-[#0e1526] p-5 rounded-xl border border-slate-800 shadow-md flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white mb-3">Safeguards de Segurança Ativos</h3>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-[#080d1a] border border-slate-800 flex items-start space-x-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">Deduplicação de Intenções (60s)</div>
                  <div className="text-[11px] text-slate-400">Filtra requisições duplicadas em janela temporal</div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#080d1a] border border-slate-800 flex items-start space-x-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">Proteção Anti-Loop Infinito</div>
                  <div className="text-[11px] text-slate-400">Limita profundidade máxima de ciclos a 3</div>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#080d1a] border border-slate-800 flex items-start space-x-3">
                <Key className="w-4 h-4 text-blue-400 mt-0.5 shrink-0" />
                <div>
                  <div className="text-xs font-semibold text-slate-200">Autorização Atômica Obrigatória</div>
                  <div className="text-[11px] text-slate-400">Exige token formal para alterações de estado</div>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('contratos')}
            className="w-full py-2 mt-4 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/80 rounded-lg border border-slate-700/50 text-center transition-colors"
          >
            Ver Especificações e Contratos
          </button>
        </div>
      </div>

      {/* Recent Audit Log Stream */}
      <div className="bg-[#0e1526] p-5 rounded-xl border border-slate-800 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white">Últimos Eventos de Auditoria</h3>
            <p className="text-xs text-slate-400">Trilha de execução com hashes SHA-256 registrados</p>
          </div>
          <button
            onClick={() => onNavigate('auditoria')}
            className="text-xs text-blue-400 hover:underline"
          >
            Abrir Console Completo
          </button>
        </div>

        <div className="space-y-2">
          {logs.slice(0, 6).map(log => (
            <div
              key={log.seq}
              className="p-3 rounded-lg bg-[#080d1a] border border-slate-800/80 hover:border-slate-700 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs"
            >
              <div className="flex items-start md:items-center space-x-3">
                <span className="px-2 py-0.5 font-mono text-[10px] bg-slate-800 text-slate-300 rounded border border-slate-700">
                  #{log.seq}
                </span>
                <span
                  className={`px-2 py-0.5 text-[10px] font-semibold rounded ${
                    log.tipo === 'DECIDIR'
                      ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      : log.tipo === 'AUTORIZACAO_EXECUCAO'
                      ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                      : log.tipo === 'ALERTA'
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  }`}
                >
                  {log.tipo}
                </span>
                <span className="font-semibold text-slate-200">{log.agente}:</span>
                <span className="text-slate-300 truncate max-w-md">{log.mensagem}</span>
              </div>

              <div className="flex items-center space-x-3 text-[11px] font-mono text-slate-500 self-end md:self-auto">
                <span className="text-slate-400 truncate max-w-[120px]">{log.hash?.slice(0, 12)}...</span>
                <span>{new Date(log.ts).toLocaleTimeString('pt-BR')}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
