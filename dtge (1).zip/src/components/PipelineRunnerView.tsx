import React, { useState } from 'react';
import { Cpu, CheckCircle2, AlertOctagon, ShieldAlert, ArrowRight, FileCode, Hash, Lock, Play, RefreshCw, Copy, Check } from 'lucide-react';

interface PipelineRunnerViewProps {
  onRunPipeline: (input: { texto_bruto: string; usuario_origem: string }) => Promise<any>;
  onRefreshAll: () => void;
}

export const PipelineRunnerView: React.FC<PipelineRunnerViewProps> = ({ onRunPipeline, onRefreshAll }) => {
  const [textoBruto, setTextoBruto] = useState('Rodar teste de integração ponta a ponta do sistema DTGE');
  const [usuarioOrigem, setUsuarioOrigem] = useState('operador_governanca');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [selectedArtifactStep, setSelectedArtifactStep] = useState<string>('qualificador');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const presets = [
    { label: 'Teste Ponta a Ponta', text: 'Rodar teste de integração ponta a ponta do sistema DTGE' },
    { label: 'Deploy de Produção', text: 'Executar deploy da nova versão e migração de banco de produção' },
    { label: 'Refatoração Módulo', text: 'Refatorar módulo de pagamentos e atualizar contratos de API' },
    { label: 'Limpeza de Dados', text: 'Executar limpeza atômica de cache expirado e reindexar hashes' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!textoBruto.trim()) return;

    setLoading(true);
    setResult(null);

    try {
      const res = await onRunPipeline({
        texto_bruto: textoBruto,
        usuario_origem: usuarioOrigem,
      });
      setResult(res);
      onRefreshAll();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(text);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const agentsList = [
    { key: 'qualificador', name: 'Qualificador', prefix: 'INT-', role: 'Filtro e Criticidade' },
    { key: 'orquestrador', name: 'Orquestrador', prefix: 'PLANO-', role: 'Plano de Ação' },
    { key: 'sentinela', name: 'Sentinela', prefix: 'RISCOS_', role: 'Auditoria de Riscos' },
    { key: 'arquiteto', name: 'Arquiteto', prefix: 'ARQUITETURA-', role: 'Blueprint Técnico' },
    { key: 'analista', name: 'Analista', prefix: 'VALIDACAO-', role: 'Validação Factual' },
    { key: 'executor', name: 'Executor', prefix: 'EXEC-', role: 'Execução Atômica' },
    { key: 'registrador', name: 'Registrador', prefix: 'HASHES_', role: 'Persistência Ledger' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center space-x-3 mb-2">
          <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Executor de Pipeline Governança</h2>
            <p className="text-slate-400 text-xs">Submeta uma intenção para processamento atômico encadeado pelos 7 agentes de governança.</p>
          </div>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Intenção Bruta / Comando de Operação
            </label>
            <textarea
              value={textoBruto}
              onChange={e => setTextoBruto(e.target.value)}
              rows={2}
              className="w-full bg-[#080d1a] border border-slate-700/80 rounded-xl p-3 text-slate-100 text-xs font-mono focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 outline-none transition-all"
              placeholder="Digite a intenção para os agentes DTGE..."
            />
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Quick Presets */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] text-slate-400">Exemplos rápidos:</span>
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setTextoBruto(preset.text)}
                  className="px-2.5 py-1 text-[11px] rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 border border-slate-700/50 transition-colors"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            {/* Operator Identifier & Execute */}
            <div className="flex items-center space-x-3 self-end sm:self-auto w-full sm:w-auto">
              <input
                type="text"
                value={usuarioOrigem}
                onChange={e => setUsuarioOrigem(e.target.value)}
                placeholder="Usuário Autor"
                className="bg-[#080d1a] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 w-36 outline-none"
              />
              <button
                type="submit"
                disabled={loading}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-lg flex items-center space-x-2 transition-all ${
                  loading
                    ? 'bg-slate-700 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/30'
                }`}
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-blue-300" />
                    <span>Processando Pipeline...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>Executar Pipeline DTGE</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Execution Results View */}
      {result && (
        <div className="space-y-6">
          {/* Status Alert Banner */}
          <div
            className={`p-4 rounded-xl border flex items-center justify-between ${
              result.sucesso
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
            }`}
          >
            <div className="flex items-center space-x-3">
              {result.sucesso ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
              ) : (
                <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0" />
              )}
              <div>
                <div className="font-bold text-sm">
                  {result.sucesso ? 'Pipeline Executado com SUCESSO Absoluto' : 'Pipeline Bloqueado pela Governança'}
                </div>
                <div className="text-xs opacity-90">
                  {result.sucesso
                    ? `${result.hashes_gerados?.length || 7} hashes SHA-256 gravados no livro-razão imutável`
                    : 'Intenção bloqueada pelo Sentinela devido ao nível de risco ou duplicação em 60s'}
                </div>
              </div>
            </div>

            <div className="text-xs font-mono bg-black/30 px-3 py-1.5 rounded-lg border border-white/10">
              HASH_MAPPING: {result.hashes_gerados?.[0]?.hash?.slice(0, 10)}...
            </div>
          </div>

          {/* Stepper Grid showing the 7 Agents */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
            {agentsList.map((agent, idx) => {
              const stepData = result.etapas?.[agent.key];
              const isSelected = selectedArtifactStep === agent.key;
              const isBlocked = result.etapas?.sentinela?.status === 'BLOQUEADO' && idx >= 2;

              return (
                <div
                  key={agent.key}
                  onClick={() => setSelectedArtifactStep(agent.key)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500 text-white ring-2 ring-blue-500/20'
                      : isBlocked
                      ? 'bg-slate-900/40 border-slate-800/60 opacity-50'
                      : 'bg-[#0e1526] border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold text-slate-400">ETAPA 0{idx + 1}</span>
                    {stepData ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : isBlocked ? (
                      <Lock className="w-3.5 h-3.5 text-rose-400" />
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-slate-600"></span>
                    )}
                  </div>
                  <div className="font-bold text-xs mt-1 text-slate-100">{agent.name}</div>
                  <div className="text-[10px] text-slate-400 truncate mt-0.5">{agent.role}</div>
                </div>
              );
            })}
          </div>

          {/* Artifact Details Inspector for Selected Step */}
          {result.etapas?.[selectedArtifactStep] && (
            <div className="bg-[#0e1526] p-5 rounded-2xl border border-slate-800 shadow-xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center space-x-2">
                  <FileCode className="w-5 h-5 text-blue-400" />
                  <h3 className="font-bold text-sm text-white capitalize">
                    Artefato do Agente: {selectedArtifactStep}
                  </h3>
                </div>

                {/* Hash Badge */}
                {result.etapas[selectedArtifactStep]?.hash && (
                  <div className="flex items-center space-x-2 bg-[#080d1a] px-3 py-1 rounded-lg border border-slate-800 text-xs font-mono">
                    <Hash className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-slate-400">SHA-256:</span>
                    <span className="text-emerald-300 font-semibold truncate max-w-xs">
                      {result.etapas[selectedArtifactStep].hash}
                    </span>
                    <button
                      onClick={() => handleCopy(result.etapas[selectedArtifactStep].hash)}
                      className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                      title="Copiar Hash"
                    >
                      {copiedHash === result.etapas[selectedArtifactStep].hash ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                )}
              </div>

              {/* JSON Visualizer */}
              <div className="bg-[#080d1a] p-4 rounded-xl border border-slate-800 overflow-x-auto">
                <pre className="text-xs font-mono text-blue-200 leading-relaxed">
                  {JSON.stringify(result.etapas[selectedArtifactStep], null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
