import React, { useState } from 'react';
import { RefreshCw, ShieldAlert, Plus, CheckCircle2, Hash, RotateCcw, AlertTriangle } from 'lucide-react';
import { CheckpointState } from '../types/dtge';

interface RollbackViewProps {
  checkpoints: CheckpointState[];
  onCreateCheckpoint: (desc: string) => Promise<any>;
  onTriggerRollback: (idCheckpoint: string) => Promise<any>;
  onRefreshAll: () => void;
}

export const RollbackView: React.FC<RollbackViewProps> = ({
  checkpoints,
  onCreateCheckpoint,
  onTriggerRollback,
  onRefreshAll,
}) => {
  const [descricao, setDescricao] = useState('');
  const [creating, setCreating] = useState(false);
  const [rollbackId, setRollbackId] = useState<string | null>(null);
  const [rollingBack, setRollingBack] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ tipo: 'sucesso' | 'erro'; texto: string } | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!descricao.trim()) return;

    setCreating(true);
    try {
      await onCreateCheckpoint(descricao);
      setDescricao('');
      setStatusMsg({ tipo: 'sucesso', texto: 'Novo Checkpoint de Estado registrado no ledger!' });
      onRefreshAll();
    } catch (err: any) {
      setStatusMsg({ tipo: 'erro', texto: err.message || 'Erro ao criar checkpoint.' });
    } finally {
      setCreating(false);
    }
  };

  const handleConfirmRollback = async () => {
    if (!rollbackId) return;

    setRollingBack(true);
    try {
      const res = await onTriggerRollback(rollbackId);
      setStatusMsg({ tipo: 'sucesso', texto: res.mensagem || 'Rollback executado com sucesso!' });
      setRollbackId(null);
      onRefreshAll();
    } catch (err: any) {
      setStatusMsg({ tipo: 'erro', texto: err.message || 'Erro ao executar rollback.' });
    } finally {
      setRollingBack(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <RefreshCw className="w-5 h-5 text-blue-400" />
            <h2 className="text-xl font-bold text-white">Checkpoints de Estado & Restauração Rollback</h2>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Gere snapshots atômicos do estado do sistema DTGE e reverta a qualquer ponto de checagem seguro com garantia de integridade.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-[#080d1a] px-3.5 py-2 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
          <ShieldAlert className="w-4 h-4 text-purple-400" />
          <span>{checkpoints.length} Checkpoints Ativos</span>
        </div>
      </div>

      {statusMsg && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
            statusMsg.tipo === 'sucesso'
              ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
          }`}
        >
          <div className="flex items-center space-x-2">
            {statusMsg.tipo === 'sucesso' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-rose-400" />}
            <span className="font-semibold">{statusMsg.texto}</span>
          </div>
          <button onClick={() => setStatusMsg(null)} className="text-xs opacity-70 hover:opacity-100">
            Fechar
          </button>
        </div>
      )}

      {/* Create Checkpoint Form */}
      <div className="bg-[#0e1526] p-5 rounded-2xl border border-slate-800 shadow-lg">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-3 flex items-center space-x-2">
          <Plus className="w-4 h-4 text-blue-400" />
          <span>Criar Novo Checkpoint de Estado</span>
        </h3>

        <form onSubmit={handleCreate} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={descricao}
            onChange={e => setDescricao(e.target.value)}
            placeholder="Descrição do checkpoint (ex: Pré-implantação da versão v1.2)..."
            className="flex-1 bg-[#080d1a] border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-200 outline-none focus:border-blue-500"
          />
          <button
            type="submit"
            disabled={creating}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center space-x-2 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Gerar Snapshot</span>
          </button>
        </form>
      </div>

      {/* Checkpoints Timeline */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-white">Linha do Tempo de Checkpoints</h3>

        <div className="space-y-3">
          {checkpoints.map((cp, idx) => (
            <div
              key={cp.id_checkpoint}
              className="bg-[#0e1526] p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center space-x-3">
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-purple-500/10 text-purple-400 rounded border border-purple-500/20">
                    CP #{checkpoints.length - idx}
                  </span>
                  <span className="font-bold text-xs font-mono text-white">{cp.id_checkpoint}</span>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {new Date(cp.ts).toLocaleString('pt-BR')}
                  </span>
                </div>

                <p className="text-xs text-slate-200 font-medium pl-1">{cp.descricao}</p>

                <div className="flex items-center space-x-4 text-[11px] text-slate-400 font-mono pt-1">
                  <span>Logs: <strong className="text-slate-200">{cp.total_logs}</strong></span>
                  <span>Hashes: <strong className="text-slate-200">{cp.total_hashes}</strong></span>
                  <span className="flex items-center space-x-1">
                    <Hash className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">{cp.hash_integridade.slice(0, 12)}...</span>
                  </span>
                </div>
              </div>

              <div className="self-end md:self-auto">
                <button
                  onClick={() => setRollbackId(cp.id_checkpoint)}
                  className="px-3.5 py-2 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-rose-400" />
                  <span>Restaurar Estado</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Rollback Confirmation Modal */}
      {rollbackId && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0e1526] max-w-md w-full rounded-2xl border border-rose-500/30 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-3 text-rose-400">
              <ShieldAlert className="w-6 h-6" />
              <h3 className="font-bold text-base text-white">Confirmar Rollback de Emergência?</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Você está prestes a restaurar o sistema DTGE para o estado do checkpoint <strong className="font-mono text-rose-300">{rollbackId}</strong>.
              Eventos posteriores serão truncados da memória ativa e um registro formal de ROLLBACK será adicionado ao log.
            </p>

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                onClick={() => setRollbackId(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold rounded-xl"
              >
                Cancelar
              </button>
              <button
                onClick={handleConfirmRollback}
                disabled={rollingBack}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-rose-600/30"
              >
                {rollingBack ? 'Restaurando...' : 'Confirmar Restauração'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
