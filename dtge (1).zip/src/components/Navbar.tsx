import React from 'react';
import { ShieldCheck, Cpu, ScrollText, Database, Activity, RefreshCw } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  summary: any;
  onRefresh: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, summary, onRefresh }) => {
  const tabs = [
    { id: 'dashboard', label: 'Painel Geral', icon: Activity },
    { id: 'pipeline', label: 'Executar Pipeline', icon: Cpu },
    { id: 'auditoria', label: 'Trilha de Auditoria', icon: ScrollText },
    { id: 'artefatos', label: 'Artefatos (Hashes)', icon: Database },
    { id: 'agentes', label: 'Rede de Agentes', icon: ShieldCheck },
    { id: 'contratos', label: 'Contratos & Canonização', icon: ScrollText },
    { id: 'rollback', label: 'Checkpoints & Rollback', icon: RefreshCw },
  ];

  return (
    <header className="bg-[#0e1526] border-b border-slate-800/80 sticky top-0 z-50 backdrop-blur-md bg-opacity-90">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 p-[1px] shadow-lg shadow-blue-500/20">
              <div className="w-full h-full bg-[#0b101d] rounded-[11px] flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-blue-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                  DTGE
                </span>
                <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full">
                  v1.0
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Dream Team Governance Engine</p>
            </div>
          </div>

          {/* Quick Metrics Badge */}
          <div className="hidden md:flex items-center space-x-4 bg-[#080d1a] px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-slate-400">Ledger Imutável:</span>
              <span className="font-mono font-semibold text-emerald-400">100% ÍNTEGRO</span>
            </div>
            <div className="h-3 w-[1px] bg-slate-800"></div>
            <div className="text-slate-400">
              Logs: <span className="font-mono text-slate-200 font-semibold">{summary?.total_logs || 0}</span>
            </div>
            <div className="h-3 w-[1px] bg-slate-800"></div>
            <div className="text-slate-400">
              Hashes SHA-256: <span className="font-mono text-slate-200 font-semibold">{summary?.total_hashes_registrados || 0}</span>
            </div>
          </div>

          {/* Refresh Action */}
          <button
            onClick={onRefresh}
            className="p-2 rounded-lg bg-slate-800/60 hover:bg-slate-700/80 text-slate-300 transition-colors text-xs flex items-center space-x-1.5 border border-slate-700/50"
            title="Atualizar dados de governança"
          >
            <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">Atualizar</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto no-scrollbar py-2 border-t border-slate-800/40">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-blue-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
