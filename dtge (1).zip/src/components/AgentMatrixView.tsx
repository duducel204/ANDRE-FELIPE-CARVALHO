import React from 'react';
import { ShieldCheck, Activity, Cpu, Lock, CheckCircle2, AlertOctagon, Terminal } from 'lucide-react';
import { AgenteInfo } from '../types/dtge';

interface AgentMatrixViewProps {
  agentes: AgenteInfo[];
  onNavigate: (tab: string) => void;
}

export const AgentMatrixView: React.FC<AgentMatrixViewProps> = ({ agentes, onNavigate }) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
            <h2 className="text-xl font-bold text-white">Rede de Agentes Governança DTGE</h2>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Matriz dos 8 agentes independentes que constituem o framework de governança multiagente.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-[#080d1a] px-3.5 py-2 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
          <Activity className="w-4 h-4 text-emerald-400" />
          <span>8 / 8 Agentes Operacionais</span>
        </div>
      </div>

      {/* Agents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {agentes.map((agente, idx) => (
          <div
            key={agente.nome}
            className="bg-[#0e1526] p-5 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
                  AGENTE 0{idx + 1}
                </span>

                <span className="px-2 py-0.5 text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20 flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span>{agente.status}</span>
                </span>
              </div>

              <h3 className="text-base font-bold text-white">{agente.nome}</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">{agente.funcao}</p>
            </div>

            <div className="space-y-2 border-t border-slate-800/80 pt-3 text-xs font-mono">
              <div className="flex items-center justify-between text-slate-400">
                <span>Execuções:</span>
                <span className="text-slate-200 font-bold">{agente.total_execucoes}</span>
              </div>

              <div className="flex items-center justify-between text-slate-400">
                <span>Criticidade Máx:</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    agente.criticidade_maxima === 'CRITICA'
                      ? 'bg-rose-500/20 text-rose-400'
                      : agente.criticidade_maxima === 'ALTA'
                      ? 'bg-amber-500/20 text-amber-400'
                      : 'bg-blue-500/20 text-blue-400'
                  }`}
                >
                  {agente.criticidade_maxima}
                </span>
              </div>

              <div className="text-[10px] text-slate-500 truncate pt-1">
                Último: <span className="text-slate-400">{agente.ultimo_evento}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#0e1526] p-5 rounded-2xl border border-slate-800 shadow-md flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Terminal className="w-5 h-5 text-blue-400" />
          <div>
            <div className="font-bold text-sm text-white">Contratos e Especificações Canonizadas</div>
            <div className="text-xs text-slate-400">Consulte as regras de negócio, limites de deduplicação e responsabilidade de cada agente.</div>
          </div>
        </div>

        <button
          onClick={() => onNavigate('contratos')}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition-all shadow-md"
        >
          Ver Documentação dos Agentes
        </button>
      </div>
    </div>
  );
};
