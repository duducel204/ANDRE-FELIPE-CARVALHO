import React, { useState } from 'react';
import { ScrollText, Search, ShieldCheck, Hash, Filter, CheckCircle2, XCircle, Copy, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { LogEntry } from '../types/dtge';

interface AuditLogViewProps {
  logs: LogEntry[];
  summary: any;
  onVerifyHash: (content: string, expectedHash: string) => Promise<boolean>;
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ logs, summary, onVerifyHash }) => {
  const [selectedAgent, setSelectedAgent] = useState('TODOS');
  const [selectedTipo, setSelectedTipo] = useState('TODOS');
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedSeq, setExpandedSeq] = useState<number | null>(null);

  // Hash verification state
  const [verifyContent, setVerifyContent] = useState('');
  const [verifyExpectedHash, setVerifyExpectedHash] = useState('');
  const [verifyResult, setVerifyResult] = useState<boolean | null>(null);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const agentsFilter = ['TODOS', 'Qualificador', 'Orquestrador', 'Sentinela', 'Arquiteto', 'Analista', 'Executor', 'Registrador', 'Rollback', 'SISTEMA'];
  const tiposFilter = ['TODOS', 'DECIDIR', 'SEGUIR', 'AUTORIZACAO_EXECUCAO', 'ALERTA', 'HASH_REGISTRADO', 'ROLLBACK'];

  const filteredLogs = logs.filter(log => {
    if (selectedAgent !== 'TODOS' && log.agente !== selectedAgent) return false;
    if (selectedTipo !== 'TODOS' && log.tipo !== selectedTipo) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchMsg = log.mensagem.toLowerCase().includes(term);
      const matchAgent = log.agente.toLowerCase().includes(term);
      const matchHash = log.hash.toLowerCase().includes(term);
      if (!matchMsg && !matchAgent && !matchHash) return false;
    }
    return true;
  });

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyContent || !verifyExpectedHash) return;
    const ok = await onVerifyHash(verifyContent, verifyExpectedHash);
    setVerifyResult(ok);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(text);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0e1526] p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <ScrollText className="w-5 h-5 text-blue-400" />
            <h2 className="text-xl font-bold text-white">Trilha Master de Auditoria</h2>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Log central de eventos imutáveis com registros de sequência, assinaturas SHA-256 e rastreabilidade atômica.
          </p>
        </div>

        <div className="flex items-center space-x-3 bg-[#080d1a] px-3.5 py-2 rounded-xl border border-slate-800 text-xs font-mono text-slate-300">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>DTGE_MASTER.log</span>
          <span className="text-slate-500">|</span>
          <span className="text-emerald-400 font-bold">{logs.length} Eventos</span>
        </div>
      </div>

      {/* SHA-256 Verification Tool Box */}
      <div className="bg-[#0e1526] p-5 rounded-2xl border border-slate-800 shadow-lg space-y-3">
        <div className="flex items-center space-x-2">
          <Hash className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Ferramenta de Verificação de Integridade SHA-256
          </h3>
        </div>

        <form onSubmit={handleVerify} className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-5">
            <input
              type="text"
              value={verifyContent}
              onChange={e => setVerifyContent(e.target.value)}
              placeholder="Conteúdo / Payload a verificar..."
              className="w-full bg-[#080d1a] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none focus:border-blue-500"
            />
          </div>
          <div className="md:col-span-5">
            <input
              type="text"
              value={verifyExpectedHash}
              onChange={e => setVerifyExpectedHash(e.target.value)}
              placeholder="Hash SHA-256 esperado..."
              className="w-full bg-[#080d1a] border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 outline-none focus:border-blue-500"
            />
          </div>
          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 rounded-xl transition-all shadow-md shadow-emerald-600/20"
            >
              Verificar Hash
            </button>
          </div>
        </form>

        {verifyResult !== null && (
          <div
            className={`p-2.5 rounded-xl border text-xs flex items-center space-x-2 ${
              verifyResult
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
            }`}
          >
            {verifyResult ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-semibold">VALIDAÇÃO OK: O hash do conteúdo confere exatamente com o hash imutável esperado!</span>
              </>
            ) : (
              <>
                <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span className="font-semibold">VIOLAÇÃO DETECTADA: O hash gerado difere do esperado. Pode indicar alteração não autorizada.</span>
              </>
            )}
          </div>
        )}
      </div>

      {/* Filter Controls */}
      <div className="bg-[#0e1526] p-4 rounded-xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 w-full md:w-auto">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Buscar por mensagem, agente ou hash..."
            className="bg-[#080d1a] border border-slate-700/80 rounded-xl px-3 py-1.5 text-slate-200 font-mono w-full md:w-64 outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto overflow-x-auto">
          <div className="flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400">Agente:</span>
            <select
              value={selectedAgent}
              onChange={e => setSelectedAgent(e.target.value)}
              className="bg-[#080d1a] border border-slate-700 rounded-lg px-2 py-1 text-slate-200 outline-none"
            >
              {agentsFilter.map(a => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-slate-400">Tipo:</span>
            <select
              value={selectedTipo}
              onChange={e => setSelectedTipo(e.target.value)}
              className="bg-[#080d1a] border border-slate-700 rounded-lg px-2 py-1 text-slate-200 outline-none"
            >
              {tiposFilter.map(t => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Log Entries Stream */}
      <div className="space-y-2">
        {filteredLogs.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs bg-[#0e1526] rounded-xl border border-slate-800">
            Nenhum evento encontrado para os filtros selecionados.
          </div>
        ) : (
          filteredLogs.map(log => {
            const isExpanded = expandedSeq === log.seq;
            return (
              <div
                key={log.seq}
                className="bg-[#0e1526] rounded-xl border border-slate-800 hover:border-slate-700 transition-all overflow-hidden"
              >
                <div
                  onClick={() => setExpandedSeq(isExpanded ? null : log.seq)}
                  className="p-3 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs"
                >
                  <div className="flex items-center space-x-3">
                    <span className="font-mono text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      #{log.seq}
                    </span>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-semibold rounded ${
                        log.tipo === 'DECIDIR'
                          ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                          : log.tipo === 'AUTORIZACAO_EXECUCAO'
                          ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                          : log.tipo === 'ALERTA'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : log.tipo === 'ROLLBACK'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {log.tipo}
                    </span>
                    <span className="font-bold text-slate-100">{log.agente}</span>
                    <span className="text-slate-300 truncate max-w-lg">{log.mensagem}</span>
                  </div>

                  <div className="flex items-center space-x-3 self-end md:self-auto font-mono text-[11px]">
                    <span className="text-slate-400">{log.hash?.slice(0, 10)}...</span>
                    <span className="text-slate-500">{new Date(log.ts).toLocaleTimeString('pt-BR')}</span>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="p-4 bg-[#080d1a] border-t border-slate-800 space-y-3">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-400">Timestamp UTC: {log.ts}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-slate-400">Hash SHA-256 Completo:</span>
                        <span className="text-emerald-400 font-bold">{log.hash}</span>
                        <button
                          onClick={() => handleCopy(log.hash)}
                          className="p-1 hover:bg-slate-800 rounded text-slate-300"
                          title="Copiar Hash"
                        >
                          {copiedHash === log.hash ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    {log.detalhes && (
                      <div>
                        <span className="text-xs font-semibold text-slate-400">Detalhes Estruturados:</span>
                        <pre className="mt-1 p-3 bg-[#0b101e] rounded-lg border border-slate-800 text-[11px] font-mono text-blue-200 overflow-x-auto">
                          {JSON.stringify(log.detalhes, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
